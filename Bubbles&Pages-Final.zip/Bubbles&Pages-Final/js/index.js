var preco = $("#preco").maskMoney();
