CREATE DATABASE loja;
USE loja;

create table usuarios (id int 
auto_increment primary key,
nome varchar(255),
email varchar(255),
senha varchar(255));
select * from usuarios

CREATE TABLE produtos (
    id INT NOT NULL AUTO_INCREMENT, 
    tipo VARCHAR(45) NOT NULL, 
    nome VARCHAR(45) NOT NULL, 
    imagem VARCHAR(80) NOT NULL, 
    preco DECIMAL(5,2) NOT NULL, 
    data_ DATE NOT NULL,
    avaliacao INT NOT NULL, 
	curtido INT NOT NULL, 
    PRIMARY KEY (id)
);

drop table produtos

INSERT INTO `produtos` (tipo, nome, imagem, preco, data_, avaliacao, curtido) VALUES
('Marvel', 'Amazing Spider-Man #23 Disney What If Infinit', 'img/feature-6.jpg', 30.00, '2023-01-01', 5, 1),
('DC Comics', 'A Saga do Batman Vol. 63', 'img/feature-1.jpg', 39.90, '2023-02-15', 4, 0),
('DC Comics', 'Hera Venenosa Vol. 01', 'img/feature-3.jpg', 32.50, '2023-03-22', 3, 1),
('DC Comics', 'Liga da Justiça Vol. 61', 'img/feature-4.jpg', 22.90, '2023-04-10', 4, 1),
('DC Comics', 'Liga da Justiça Vol. 61', 'img/feature-4.jpg', 22.90, '2023-04-10', 4, 0),
('DC Comics', 'Liga da Justiça Vol. 61', 'img/feature-4.jpg', 22.90, '2023-04-10', 4, 0);
 
SELECT * FROM produtos ORDER BY curtido DESC LIMIT 6



--VERSÃO 2

CREATE DATABASE loja;
USE loja;

create table usuarios (id int 
auto_increment primary key,
nome varchar(255),
email varchar(255),
senha varchar(255));
select * from usuarios;

INSERT INTO usuarios (nome, email, senha) VALUES
    ('admin', 'admin@gmail.com', 'P@ssw0rd123'),
    ('Laiss Vasques', 'laiss@gmail.com', 'FlorAmarela456'),
    ('Amanda Araujo', 'amanda@gmail.com', 'CeuAzul789'),
    ('Lucas Oliveira', 'lucas@gmail.com', 'Montanha123'),
    ('Juliana Silva', 'juliana@gmail.com', 'OndaMar456'),
    ('Rafael Souza', 'rafael@gmail.com', 'VagaLume789'),
    ('Carolina Santos', 'carolina@gmail.com', 'Estrela123');

CREATE TABLE produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo VARCHAR(255),
    nome VARCHAR(255),
    imagem VARCHAR(255),
    descricao TEXT,
    preco DECIMAL(10, 2),
    avaliacao DECIMAL(3, 2),
    curtido INT,
    data_ DATETIME DEFAULT NOW()
);

INSERT INTO produtos (tipo, nome, imagem, descricao, preco, avaliacao, curtido)
VALUES
  ('Marvel', 'Deadpool Capa Variante Vol. 2', 'img/deadpool-comic.jpg', 'Capa variante do Deadpool, Volume 2', 59.90, 4.2, 120),
  ('Marvel', 'Spider-Punk Vol. 1', 'img/spiderpunk-comic.jpg', 'Spider-Punk Volume 1 da Marvel', 45.90, 4.5, 80),
  ('Marvel', 'Amazing Spider-Man #23 Disney What If Infinity Gauntlet', 'img/infinitgaulent-comic.jpg', 'Edição especial da Marvel - What If Infinity Gauntlet', 30.00, 4.0, 95),
  ('Manga', 'Blue Period Vol. 1', 'img/blueperiod-manga.jpg', 'Manga Blue Period, Volume 1', 34.90, 4.8, 150),
  ('Manga', 'Kuroko no Basket Vol. 6', 'img/kurokonobasket-comic.jpg', 'Manga Kuroko no Basket, Volume 6', 24.90, 4.3, 110),
  ('Quadrinhos', 'Mônica(2021) Vol. 26', 'img/monica26-quadrinhos.jpg', 'Edição 26 da Turma da Mônica lançada em 2021', 8.00, 3.7, 60),
  ('Quadrinhos', 'Magali(2021) Vol.34', 'img/magali34-quadrinhos.jpg', 'Edição 34 da Turma da Magali lançada em 2021', 8.00, 3.9, 75),
  ('Quadrinhos', 'Cebolinha(2021) Vol. 39', 'img/cebolinha39-quadrinhos.jpg', 'Edição 39 da Turma do Cebolinha lançada em 2021', 8.00, 4.1, 90),
  ('Quadrinhos', 'Cascão(2021) Vol. 29', 'img/cascao29-quadrinhos.jpg', 'Edição 29 da Turma do Cascão lançada em 2021', 8.00, 3.5, 50),
('DC Comics', 'A Saga do Batman Vol. 63', 'img/batman-comic30.jpg', 'Edição 29 da Turma do Cascão lançada em 2021', 39.90, 3.5, 50),
('DC Comics', 'Liga da Justiça Vol. 61', 'img/ligadajustica-comic61.jpg', 'Edição 29 da Turma do Cascão lançada em 2021', 22.90, 3.5, 50);


  ('DC Comics', 'Hera Venenosa Vol. 01', 'heravenenosa-comic01.jpg', 'Edição 29 da Turma do Cascão lançada em 2021', 32.50, 3.5, 50),
  
  select * from produtos;
  
  SELECT * FROM produtos ORDER BY curtido DESC LIMIT 6;
