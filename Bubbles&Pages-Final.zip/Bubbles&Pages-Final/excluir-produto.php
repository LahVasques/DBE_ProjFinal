<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Bubbles & Pages - Excluir Produto</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
	<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;600;900&display=swap" rel="stylesheet">
</head>
<body>
	
	<div class="limiter">
    <div class="cadastro">
        </div>
            <div class="container-login100">
                <div class="wrap-login100">
                <section>
                  <?php
                  require "conexao.php";
                  $id = $_GET['id'];
                  $sql = "select * from produtos where id = '$id'";
                  $result = $conn->query($sql);

                  $row = $result->fetch_assoc();

                  ?>
                    <form class="login100-form validate-form" action="processar-excluir-produto.php" method="POST" enctype="multipart/form-data" onsubmit="excluirProduto();" id="editarForm">
                        <span class="login100-form-title p-b-48">
                            <i class="zmdi zmdi-font"></i>
                        </span>

                        <div class="wrap-input100 validate-input" >
                            <input class="input100" type="text" id="nome" name="nome" value="<?php echo $row['nome']; ?>" readonly="readonly" />
                            <span class="focus-input100" ></span>
                        </div>

                        <div class="wrap-input100 validate-input">
                            <span class="btn-show-pass">
                                <i class="zmdi zmdi-eye"></i>
                            </span>
                            <input class="input100" type="text" id="preco" name="preco" value="<?php echo $row['preco']; ?>" readonly="readonly" />
                            <span class="focus-input100"  ></span>
                        </div>

                        <div class="select">
                            <div>
                                <label for="marvel">Marvel</label>
                                <input type="radio" id="marvel" name="tipo" value="Marvel" onclick="return false;" <?php if ($row['tipo'] == "Marvel") {
                                                                      echo 'checked';
                                                                    } ?> >
                            </div>
                            <div>
                                <label for="dc">DC Comics</label>
                                <input type="radio" id="dc" name="tipo" value="DC Comics" onclick="return false;"  <?php if ($row['tipo'] == "DC Comics") {
                                                                          echo 'checked';
                                                                        } ?> >
                            </div>
                            <div>
                                <label for="quadrinhos">Quadrinhos</label>
                                <input type="radio" id="quadrinhos" name="tipo" value="Quadrinhos" onclick="return false;" <?php if ($row['tipo'] == "Quadrinhos") {
                                                                          echo 'checked';
                                                                        } ?> >
                            </div>
                            <div>
                                <label for="manga">Mangás</label>
                                <input type="radio" id="manga" name="tipo" value="Mangás" onclick="return false;" <?php if ($row['tipo'] == "Mangás") {
                                                                          echo 'checked';
                                                                        } ?> >
                            </div>
                        </div>

                        <input type="file" name="imagem" accept="image/*" id="imagem" value="img/<?php echo $imagem;?>">

                        <input type="hidden" name="id" id="id" value="<?= $row['id']; ?>">

                        <div class="container-login100-form-btn">
                            <div class="wrap-login100-form-btn">
                                <div class="login100-form-bgbtn"></div>
                                <button class="login100-form-btn" type="submit">
                                    Excluir produto
                                </button>
                            </div>
                        </div>
                    </form>
                  </section>
                </div>
            </div>
        </div>
    </div>
	</div>
	

	<div id="dropDownSelect1"></div>

  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
	
  <script>
    

    function excluirProduto() {
      event.preventDefault(); // Impede o envio padrão do formulário

      const nome = document.getElementById("nome").value;
      const tipo = document.querySelector('input[name="tipo"]:checked').value;
      const preco = document.getElementById("preco").value;
      const id = document.getElementById("id").value;

      Swal.fire({
        title: "Confirme a exclusão do produto",
        html: `<strong>Nome:</strong> ${nome}<br>
          <strong>Tipo:</strong> ${tipo}<br>
          <strong>Preço:</strong> ${preco}<br>`,
        showDenyButton: true,
        
        confirmButtonText: "Excluir",
        denyButtonText: "Cancelar",

      }).then((result) => {
        if (result.isConfirmed) {
          // Se o usuário confirmar a edição, redirecione para outra página
          const url = `processar-excluir-produto.php?nome=${nome}&tipo=${tipo}&preco=${preco}&id=${id}`;
          window.location.href = url;
        } else if (result.isDenied) {
          Swal.fire("Exclusão cancelada", "", "info");
        }
      });

      // Impede o envio do formulário
      return false;
    }
  </script>


<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main_login.js"></script>

</body>
</html>