<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "loja";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar a conexão
if (!$conn) {
    die("Falha na conexão: " . mysqli_connect_error());
}

// Dados do usuário a serem verificados (supondo que você tenha um formulário para isso)
$emailParaVerificar = $_POST['email'];
$senhaParaVerificar = $_POST['senha'];

// Consulta SQL para verificar o login
$sql = "SELECT * FROM usuarios WHERE email = '$emailParaVerificar' AND senha = '$senhaParaVerificar'";
$resultado = mysqli_query($conn, $sql);

// Verificar se a consulta foi bem-sucedida e se há um registro correspondente
if ($resultado->num_rows == 1) {
    // Recupera os dados do usuário
    $usuario = $resultado->fetch_assoc();

    // Verifica se o usuário é administrador (usando o email e o id)
    if ($usuario['id'] == 1) {
        // Login do administrador, redirecionar para a página do admin
        header("Location: admin.php");
        exit();
    } else {
        // Não é o login do administrador, redirecionar para a página de login
        header("Location: index.php");
        exit();
    }
} else {
    // E-mail ou senha incorretos, redirecionar para a página de login
    header("Location: index.php");
    exit();
}

// Fechar a conexão com o banco de dados
$conn->close();



// require_once "conexao2.php";
// // Obter os dados do formulário
// // $nome = $_POST["nome"];
// $email = $_POST["email"];
// $senha = $_POST["senha"];
// // Inserir os dados na tabela 'usuario'
// $sql = "SELECT * FROM usuarios (email, senha) VALUES 
// ('$email', '$senha')";

// if ($conn->query($sql) === TRUE) {
//     header("Location: index.php");
//     exit();    
// } else {
//     echo "Erro ao cadastrar o usuario: " . $conn->error;
// }
// $conn->close();
?>